﻿Read Me!
u\zippity21 : I did not write this. I've merely updated it to work with .NET 5 and Monogame64 which is the new target framework for Stardew Valley.
This was updated in good faith, but without authorization (since the original author appears to have abandoned the project, and left no means of contact).
There is no warranty, expressed or implied, and there is no guarantee of fitness for a particular purpose.

Updateded for Stardew Valley 1.5.5 beta, so until it officially releases, you MUST use the beta channel in Steam.

1) Look at https://stardewvalleywiki.com/Modding:Player_Guide/Getting_Started for general mod installation instructions
2) Install SMAPI 3.13.0-beta.20211018 https://github.com/Pathoschild/SMAPI/releases/download/3.13.0-beta.20211018/SMAPI-3.13.0-beta.20211018-installer.zip
3) Install most recent PyTK mod https://www.nexusmods.com/stardewvalley/mods/1726
4) Install this mod
